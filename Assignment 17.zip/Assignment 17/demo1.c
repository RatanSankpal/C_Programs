#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int data;              // Data part
	struct node *next;     // Link part

} Node_t;


Node_t *head;

 
void init_list()
{
	 
	head = NULL;
}

  
void insert_first(int data)
{
	// Step 1: Create a new node.
	Node_t *newnode;

	newnode = (Node_t *)malloc(sizeof(Node_t));

	// Step 2: Initialize the new node.
	newnode->data = data;
	newnode->next = NULL;

	// Step 3:Check whether the list is empty.
	if(head == NULL)
	{
        // First node points to itself.
		head = newnode;
		newnode->next = head;
		return;
	}

	// Step 4:Traverse upto the last node.
	Node_t *trav = head;
	while(trav->next != head)
	{
		trav = trav->next;
	}

	// Step 5: Adjust links.
	trav->next = newnode;
	newnode->next = head;
	head = newnode;
}

 
void insert_last(int data)
{
	// Step 1:Create a new node.
	Node_t *newnode;

	newnode = (Node_t *)malloc(sizeof(Node_t));
	
    // Step 2:Initialize the node.

	newnode->data = data;
	newnode->next = NULL;

	// Step 3:Check whether the list is empty.
	if(head == NULL)
	{
		// First node points to itself.
		head = newnode;
		newnode->next = head;
		return;
	}

	// Step 4:Traverse upto the last node.
	Node_t *trav = head;
	while(trav->next != head)
	{
		trav = trav->next;
	}

	// Step 5: Insert the new node after the last node.
	trav->next = newnode;
	newnode->next = head;
}

 
void traverse_list()
{
	// Step 1:Check whether the list is empty.
	if(head == NULL)
	{
		printf("List is empty.\n");
		return;
	}

	// Step 2:Create a traversal pointer and initialize it with head.
	Node_t *trav = head;

	// Step 3:Traverse the complete circular list.Stop when traversal pointer again reaches the head node.
	do
	{
		printf("%d -> ", trav->data); // Display data of the current node.
		trav = trav->next;            // Move to the next node.

	}while(trav != head); //traversal pointer again reaches the head node.

	printf("(HEAD)\n");
}

  
int count_list()
{
	// Step 1:Initialize counter.
	int cnt = 0;

	// Step 2: Check whether the list is empty.
	if(head == NULL)
	{
		return 0;
	}
	// Step 3: Traverse the circular list.
	Node_t *trav = head;
	do
	{
		cnt++;              // Increment counter for each node.
		trav = trav->next;  // Move to the next node.
	}while(trav != head);   // Stop when traversal pointer again reaches the head node.

	// Step 4: Return total node count.
	return cnt;
}

 

void insert_pos(int data, int pos)
{
	// Step 1:Count total nodes.

	int cnt = count_list();
	// Step 2: Insert at beginning.
	if(pos == 1) //if position is 1, insert at beginning.
	{
		insert_first(data);
		return;
	}

	// Step 3: Insert at last.
	else if(pos == cnt + 1)  //if position is (count + 1), insert at last.
	{
		insert_last(data);
		return;
	}

	// Step 4: Insert in the middle.

	else if(pos > 1 && pos <= cnt)
	{
		// Create a new node.
		Node_t *newnode;

		newnode = (Node_t *)malloc(sizeof(Node_t));
		newnode->data = data;
		newnode->next = NULL;

		// Traverse upto (position-1).
		Node_t *trav = head;
		int i = 1;
		while(i < pos - 1)
		{
			trav = trav->next;
			i++;
		}
		// Adjust links.
		newnode->next = trav->next;
		trav->next = newnode;
		return;
	}

	// Step 5: Invalid position.
    else
    {
	    printf("Invalid Position.\n");
    }
}

 
void delete_first()
{
	// Step 1:Check whether the list is empty.
	if(head == NULL)
	{
		printf("List is empty.\n");
		return;
	}

	// Step 2:Check whether only one node is present.
	else if(head == head->next)
	{
		free(head);
		head = NULL;
		return;
	}

    else
    {
        // Step 3: Traverse upto the last node.
        Node_t *trav = head;
        while(trav->next != head)
        {
            trav = trav->next;
        }
        // Step 4: Store the first node.
        Node_t *temp = head;

        // Step 5: Move head to the second node.
        head = head->next;

        // Step 6: Last node should point to new head.
        trav->next = head;

        // Step 7: Delete old first node.
        free(temp);
    }   
}
 

void delete_last()
{
	// Step 1:Check whether the list is empty.
	if(head == NULL)
	{
		printf("List is empty.\n");
		return;
	}

	// Step 2:Check whether only one node exists.
	if(head == head->next)
	{
		free(head);
		head = NULL;
		return;
	}
    else
    {
        // Step 3:Traverse upto the second last node.
        Node_t *trav = head;
        while(trav->next->next != head)
        {
            trav = trav->next;
        }
        // Step 4:Delete the last node.
        Node_t *temp = trav->next;
        trav->next = head;
        free(temp);
    }
}

 
void delete_pos(int pos)
{
	// Step 1: Count total nodes.
	int cnt = count_list();

	// Step 2: Delete first node.
	if(pos == 1)
	{
		delete_first();
		return;
	}

	// Step 3:Delete last node.
	if(pos == cnt)
	{
		delete_last();
		return;
	}

	// Step 4: Delete node from middle.

	if(pos > 1 && pos < cnt)
	{
		Node_t *trav = head;
		Node_t *temp;
		int i = 1;
		// Traverse upto (position-1).
		while(i < pos - 1)
		{
			trav = trav->next;
			i++;
		}
		// Remove the node.
		temp = trav->next;
		trav->next = temp->next;
		free(temp);
		return;
	}

	// Step 5: Invalid position.
	printf("Invalid Position.\n");
}

 
void delete_all()
{
	// Step 1: Check whether the list is empty.
	if(head == NULL)
	{
		printf("List is empty.\n");

		return;
	}

	// Step 2: Delete first node repeatedly until the list becomes empty.
	while(head != NULL)
	{
		delete_first();
	}
}
 

int main()
{
    // Initialize the Circular Linked List.
	init_list();

    // Insert nodes at the beginning.
	insert_first( 50 );
	insert_first( 40 );
	insert_first( 30 );
	insert_first( 20 );
	insert_first( 10 );

    // Display the list.
	traverse_list();

    // Delete all nodes.
	delete_all();
	traverse_list();

	/*
    // Delete node at position 
	delete_pos(3);
	traverse_list();
	*/

	/*
    // Delete last node repeatedly.
	delete_last();
	traverse_list();
	delete_last();
	traverse_list();
	delete_last();
	traverse_list();
	*/

	/*
    // Delete first node repeatedly.
	delete_first();
	traverse_list();
	delete_first();
	traverse_list();
	*/

	/*
    // Insert nodes at specified positions.
	insert_pos(25, 3);
	traverse_list();
	insert_pos(35, 5);
	traverse_list();
	*/

	printf("Node count : %d \n",count_list());
	/*
    // Insert nodes at the end.
	insert_last( 50 );
	traverse_list();
	insert_last( 60 );
	traverse_list();
	*/

	return 0;
}